This is basically a TIC TAC TOE game.
It is built on assembly language for masmx8086 processor.
A player_score file is created that saves scores of each player.
Please support me and share this project.
Thanking you!